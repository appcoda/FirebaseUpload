//
//  FireCollectionViewCell.swift
//  FireUploadStarter
//
//  Created by Kuan L. Chen on 07/03/2017.
//  Copyright © 2017 AppCoda. All rights reserved.
//

import UIKit

class FireCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var fireImageView: UIImageView!
    
}
